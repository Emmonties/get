# dict-get

Use "." to get the value of a JSON object. Just like JavaScripthat gets the value of an object

